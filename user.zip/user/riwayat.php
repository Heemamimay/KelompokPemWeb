<?php
$pageTitle = 'Riwayat Transaksi';
require_once __DIR__ . '/user_header.php';

$uid = (int)$_SESSION['user_id'];
$transaksi = $conn->query("SELECT * FROM transaksi WHERE id_pelanggan=$uid ORDER BY tanggal DESC");
?>

<div class="page-header">
  <h1>Riwayat Transaksi 📋</h1>
</div>

<?php if(isset($_GET['success'])): ?>
<div class="alert alert-success" data-autodismiss>✅ Checkout berhasil! Pesananmu sedang diproses.</div>
<?php endif; ?>

<?php if($transaksi->num_rows > 0): ?>
<div class="table-wrapper">
  <table>
    <thead>
      <tr>
        <th>#ID</th>
        <th>Tanggal</th>
        <th>Total</th>
        <th>Status</th>
        <th>Detail</th>
      </tr>
    </thead>
    <tbody>
      <?php while($t = $transaksi->fetch_assoc()): ?>
      <tr>
        <td><strong>#<?= $t['id_transaksi'] ?></strong></td>
        <td><?= date('d/m/Y H:i', strtotime($t['tanggal'])) ?></td>
        <td><?= formatRupiah($t['total_harga']) ?></td>
        <td><span class="badge badge-<?= $t['status'] ?>"><?= ucfirst($t['status']) ?></span></td>
        <td>
          <a href="detail_transaksi.php?id=<?= $t['id_transaksi'] ?>" class="btn btn-outline btn-sm">Lihat</a>
        </td>
      </tr>
      <?php endwhile; ?>
    </tbody>
  </table>
</div>
<?php else: ?>
<div class="empty-state">
  <div class="icon">📋</div>
  <h3>Belum Ada Transaksi</h3>
  <p>Kamu belum pernah melakukan transaksi</p>
  <a href="<?= BASE_URL ?>/produk.php" class="btn btn-primary">Mulai Belanja</a>
</div>
<?php endif; ?>

<?php require_once __DIR__ . '/user_footer.php'; ?>