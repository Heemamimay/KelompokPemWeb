<?php
if (session_status() === PHP_SESSION_NONE) session_start();
require_once __DIR__ . '/../includes/config.php';
redirectIfNotUser();
$userName    = $_SESSION['user_nama'] ?? 'Pengguna';
$activePage  = basename($_SERVER['PHP_SELF'], '.php');

// Cart count
$uid = (int)$_SESSION['user_id'];
$cartRes = $conn->query("SELECT SUM(jumlah) as total FROM keranjang WHERE id_pelanggan=$uid");
$cartCount = $cartRes ? (int)$cartRes->fetch_assoc()['total'] : 0;
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title><?= isset($pageTitle) ? $pageTitle . ' - SEMBARANG STORE' : 'SEMBARANG STORE' ?></title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="<?= BASE_URL ?>/assets/css/style.css">
</head>
<body>
<div class="dashboard-layout">

  <aside class="sidebar" id="sidebar">
    <div class="sidebar-logo">
      <h3>👟 SEMBARANG</h3>
      <p>Halo, <?= htmlspecialchars($userName) ?></p>
    </div>

    <nav class="sidebar-nav">
      <div class="sidebar-section-label">Menu</div>
      <a href="<?= BASE_URL ?>/user/dashboard.php"
         class="sidebar-link <?= $activePage==='dashboard'?'active':'' ?>">
        <span class="icon">🏠</span> Dashboard
      </a>
      <a href="<?= BASE_URL ?>/produk.php"
         class="sidebar-link">
        <span class="icon">🛍️</span> Semua Produk
      </a>
      <a href="<?= BASE_URL ?>/user/keranjang.php"
         class="sidebar-link <?= $activePage==='keranjang'?'active':'' ?>">
        <span class="icon">🛒</span> Keranjang
        <?php if($cartCount > 0): ?>
          <span style="margin-left:auto;background:var(--gold);color:#000;border-radius:99px;font-size:.65rem;font-weight:700;padding:2px 8px;"><?= $cartCount ?></span>
        <?php endif; ?>
      </a>
      <a href="<?= BASE_URL ?>/user/riwayat.php"
         class="sidebar-link <?= $activePage==='riwayat'?'active':'' ?>">
        <span class="icon">📋</span> Riwayat Transaksi
      </a>
      <a href="<?= BASE_URL ?>/user/profil.php"
         class="sidebar-link <?= $activePage==='profil'?'active':'' ?>">
        <span class="icon">⚙️</span> Profil Saya
      </a>
    </nav>

    <div class="sidebar-footer">
      <a href="<?= BASE_URL ?>/user/logout.php" class="sidebar-link"
         data-confirm="Yakin ingin logout?">
        <span class="icon">🚪</span> Logout
      </a>
    </div>
  </aside>

  <main class="main-content">
    <div style="display:flex;align-items:center;gap:12px;margin-bottom:24px;padding-bottom:16px;border-bottom:1px solid var(--card-border);">
      <button id="sidebarToggle" style="background:none;border:none;color:var(--white);font-size:1.4rem;cursor:pointer;display:none;">☰</button>
      <span style="font-size:.85rem;color:var(--white-dim);">
        <a href="<?= BASE_URL ?>/index.php" style="color:var(--purple-glow);">SEMBARANG STORE</a>
      </span>
    </div>
    <style>@media(max-width:1024px){#sidebarToggle{display:flex!important;}}</style>
