<?php
$pageTitle = 'Dashboard';
require_once __DIR__ . '/user_header.php';

// Ambil data transaksi user
$uid = (int)$_SESSION['user_id'];
$totalTransaksi = $conn->query("SELECT COUNT(*) as c FROM transaksi WHERE id_pelanggan=$uid")->fetch_assoc()['c'];
$totalBelanja   = $conn->query("SELECT IFNULL(SUM(total_harga),0) as c FROM transaksi WHERE id_pelanggan=$uid AND status='selesai'")->fetch_assoc()['c'];
$transaksiTerbaru = $conn->query("SELECT * FROM transaksi WHERE id_pelanggan=$uid ORDER BY tanggal DESC LIMIT 5");

// Keranjang count
$cartCount2 = $conn->query("SELECT COUNT(*) as c FROM keranjang WHERE id_pelanggan=$uid")->fetch_assoc()['c'];
?>

<div class="page-header">
  <div>
    <h1>Halo, <?= htmlspecialchars($userName) ?>! 👋</h1>
    <p>Selamat datang di dashboard kamu</p>
  </div>
</div>

<!-- Stat Cards -->
<div class="stat-cards">
  <div class="stat-card">
    <div class="stat-card-icon purple">📋</div>
    <div class="stat-card-info">
      <h3><?= $totalTransaksi ?></h3>
      <p>Total Transaksi</p>
    </div>
  </div>
  <div class="stat-card">
    <div class="stat-card-icon gold">💰</div>
    <div class="stat-card-info">
      <h3 style="font-size:1rem;"><?= formatRupiah($totalBelanja) ?></h3>
      <p>Total Belanja</p>
    </div>
  </div>
  <div class="stat-card">
    <div class="stat-card-icon green">🛒</div>
    <div class="stat-card-info">
      <h3><?= $cartCount2 ?></h3>
      <p>Item di Keranjang</p>
    </div>
  </div>
</div>

<!-- Transaksi Terbaru -->
<div class="table-wrapper">
  <div class="table-header">
    <h3>Transaksi Terbaru</h3>
    <a href="<?= BASE_URL ?>/user/riwayat.php" class="btn btn-outline btn-sm">Lihat Semua</a>
  </div>
  <?php if($transaksiTerbaru->num_rows > 0): ?>
  <table>
    <thead>
      <tr>
        <th>#ID</th>
        <th>Total</th>
        <th>Status</th>
        <th>Tanggal</th>
      </tr>
    </thead>
    <tbody>
      <?php while($t = $transaksiTerbaru->fetch_assoc()): ?>
      <tr>
        <td><strong>#<?= $t['id_transaksi'] ?></strong></td>
        <td><?= formatRupiah($t['total_harga']) ?></td>
        <td><span class="badge badge-<?= $t['status'] ?>"><?= ucfirst($t['status']) ?></span></td>
        <td><?= date('d/m/Y', strtotime($t['tanggal'])) ?></td>
      </tr>
      <?php endwhile; ?>
    </tbody>
  </table>
  <?php else: ?>
  <div style="padding:32px; text-align:center; color:var(--white-dim);">
    Belum ada transaksi. <a href="<?= BASE_URL ?>/produk.php" style="color:var(--purple-glow);">Mulai belanja!</a>
  </div>
  <?php endif; ?>
</div>

<?php require_once __DIR__ . '/user_footer.php'; ?>