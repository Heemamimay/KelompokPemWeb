<?php
$pageTitle = 'Keranjang';
require_once __DIR__ . '/user_header.php';

$uid = (int)$_SESSION['user_id'];

// Tambah ke keranjang
if (isset($_GET['add'])) {
    $id_barang = (int)$_GET['add'];
    $cek = $conn->query("SELECT * FROM keranjang WHERE id_pelanggan=$uid AND id_barang=$id_barang");
    if ($cek->num_rows > 0) {
        $conn->query("UPDATE keranjang SET jumlah=jumlah+1 WHERE id_pelanggan=$uid AND id_barang=$id_barang");
    } else {
        $conn->query("INSERT INTO keranjang (id_pelanggan,id_barang,jumlah) VALUES ($uid,$id_barang,1)");
    }
    header('Location: keranjang.php');
    exit();
}

// Hapus dari keranjang
if (isset($_GET['remove'])) {
    $id_keranjang = (int)$_GET['remove'];
    $conn->query("DELETE FROM keranjang WHERE id_keranjang=$id_keranjang AND id_pelanggan=$uid");
    header('Location: keranjang.php');
    exit();
}

// Update jumlah
if (isset($_GET['update']) && isset($_GET['jumlah'])) {
    $id_keranjang = (int)$_GET['update'];
    $jumlah = max(1, (int)$_GET['jumlah']);
    $conn->query("UPDATE keranjang SET jumlah=$jumlah WHERE id_keranjang=$id_keranjang AND id_pelanggan=$uid");
    header('Location: keranjang.php');
    exit();
}

// Checkout
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['checkout'])) {
    $items = $conn->query("SELECT k.*, b.harga, b.stok FROM keranjang k JOIN barang b ON k.id_barang=b.id_barang WHERE k.id_pelanggan=$uid");
    if ($items->num_rows > 0) {
        $total = 0;
        $itemsArr = [];
        while ($item = $items->fetch_assoc()) {
            $subtotal = $item['harga'] * $item['jumlah'];
            $total += $subtotal;
            $itemsArr[] = $item;
        }
        // Insert transaksi
        $conn->query("INSERT INTO transaksi (id_pelanggan, total_harga, status) VALUES ($uid, $total, 'pending')");
        $id_transaksi = $conn->insert_id;
        // Insert detail
        foreach ($itemsArr as $item) {
            $subtotal = $item['harga'] * $item['jumlah'];
            $conn->query("INSERT INTO detail_transaksi (id_transaksi, id_barang, jumlah, subtotal) VALUES ($id_transaksi, {$item['id_barang']}, {$item['jumlah']}, $subtotal)");
            // Kurangi stok
            $conn->query("UPDATE barang SET stok=stok-{$item['jumlah']} WHERE id_barang={$item['id_barang']}");
        }
        // Kosongkan keranjang
        $conn->query("DELETE FROM keranjang WHERE id_pelanggan=$uid");
        header('Location: riwayat.php?success=1');
        exit();
    }
}

// Ambil isi keranjang
$keranjang = $conn->query("SELECT k.*, b.nama_barang, b.merk, b.harga, b.stok FROM keranjang k JOIN barang b ON k.id_barang=b.id_barang WHERE k.id_pelanggan=$uid");
$total = 0;
$items = [];
while ($item = $keranjang->fetch_assoc()) {
    $item['subtotal'] = $item['harga'] * $item['jumlah'];
    $total += $item['subtotal'];
    $items[] = $item;
}
?>

<div class="page-header">
  <h1>Keranjang Belanja 🛒</h1>
</div>

<?php if(count($items) > 0): ?>
<div class="table-wrapper">
  <table>
    <thead>
      <tr>
        <th>Produk</th>
        <th>Harga</th>
        <th>Jumlah</th>
        <th>Subtotal</th>
        <th>Aksi</th>
      </tr>
    </thead>
    <tbody>
      <?php foreach($items as $item): ?>
      <tr>
        <td>
          <strong><?= htmlspecialchars($item['nama_barang']) ?></strong><br>
          <small style="color:var(--white-dim);"><?= htmlspecialchars($item['merk']) ?></small>
        </td>
        <td><?= formatRupiah($item['harga']) ?></td>
        <td>
          <div style="display:flex; gap:6px; align-items:center;">
            <a href="?update=<?= $item['id_keranjang'] ?>&jumlah=<?= max(1,$item['jumlah']-1) ?>" class="btn btn-outline btn-sm">-</a>
            <span><?= $item['jumlah'] ?></span>
            <a href="?update=<?= $item['id_keranjang'] ?>&jumlah=<?= $item['jumlah']+1 ?>" class="btn btn-outline btn-sm">+</a>
          </div>
        </td>
        <td><?= formatRupiah($item['subtotal']) ?></td>
        <td>
          <a href="?remove=<?= $item['id_keranjang'] ?>" class="btn btn-sm"
             style="background:rgba(255,77,109,.15); color:#ff4d6d;"
             onclick="return confirm('Hapus item ini?')">🗑️</a>
        </td>
      </tr>
      <?php endforeach; ?>
    </tbody>
  </table>
</div>

<div style="display:flex; justify-content:flex-end; margin-top:24px;">
  <div class="card" style="min-width:300px; padding:24px;">
    <div style="display:flex; justify-content:space-between; margin-bottom:16px;">
      <span style="color:var(--white-dim);">Total Belanja</span>
      <strong style="font-size:1.2rem; color:var(--gold);"><?= formatRupiah($total) ?></strong>
    </div>
    <form method="POST">
      <button type="submit" name="checkout" class="btn btn-primary btn-block"
              onclick="return confirm('Lanjutkan checkout?')">
        ✅ Checkout Sekarang
      </button>
    </form>
    <a href="<?= BASE_URL ?>/produk.php" class="btn btn-outline btn-block mt-2">← Lanjut Belanja</a>
  </div>
</div>

<?php else: ?>
<div class="empty-state">
  <div class="icon">🛒</div>
  <h3>Keranjang Kosong</h3>
  <p>Belum ada produk di keranjangmu</p>
  <a href="<?= BASE_URL ?>/produk.php" class="btn btn-primary">Mulai Belanja</a>
</div>
<?php endif; ?>

<?php require_once __DIR__ . '/user_footer.php'; ?>