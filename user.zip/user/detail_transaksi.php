<?php
$pageTitle = 'Detail Transaksi';
require_once __DIR__ . '/user_header.php';

$uid = (int)$_SESSION['user_id'];
$id  = (int)($_GET['id'] ?? 0);

if (!$id) { header('Location: riwayat.php'); exit(); }

$transaksi = $conn->query("SELECT * FROM transaksi WHERE id_transaksi=$id AND id_pelanggan=$uid")->fetch_assoc();
if (!$transaksi) { header('Location: riwayat.php'); exit(); }

$detail = $conn->query("SELECT dt.*, b.nama_barang, b.merk FROM detail_transaksi dt JOIN barang b ON dt.id_barang=b.id_barang WHERE dt.id_transaksi=$id");
?>

<div class="page-header">
  <div>
    <h1>Detail Transaksi #<?= $id ?></h1>
    <p><?= date('d F Y, H:i', strtotime($transaksi['tanggal'])) ?></p>
  </div>
  <a href="riwayat.php" class="btn btn-outline">← Kembali</a>
</div>

<div style="display:grid; gap:24px;">

  <div class="table-wrapper">
    <div class="table-header">
      <h3>Item Pesanan</h3>
      <span class="badge badge-<?= $transaksi['status'] ?>"><?= ucfirst($transaksi['status']) ?></span>
    </div>
    <table>
      <thead>
        <tr>
          <th>Produk</th>
          <th>Brand</th>
          <th>Jumlah</th>
          <th>Subtotal</th>
        </tr>
      </thead>
      <tbody>
        <?php while($d = $detail->fetch_assoc()): ?>
        <tr>
          <td><?= htmlspecialchars($d['nama_barang']) ?></td>
          <td><?= htmlspecialchars($d['merk']) ?></td>
          <td><?= $d['jumlah'] ?></td>
          <td><?= formatRupiah($d['subtotal']) ?></td>
        </tr>
        <?php endwhile; ?>
      </tbody>
    </table>
  </div>

  <div style="display:flex; justify-content:flex-end;">
    <div class="card" style="padding:24px; min-width:260px;">
      <div style="display:flex; justify-content:space-between; margin-bottom:8px;">
        <span style="color:var(--white-dim);">Total Pembayaran</span>
        <strong style="color:var(--gold); font-size:1.2rem;"><?= formatRupiah($transaksi['total_harga']) ?></strong>
      </div>
      <div style="display:flex; justify-content:space-between;">
        <span style="color:var(--white-dim);">Status</span>
        <span class="badge badge-<?= $transaksi['status'] ?>"><?= ucfirst($transaksi['status']) ?></span>
      </div>
    </div>
  </div>

</div>

<?php require_once __DIR__ . '/user_footer.php'; ?>