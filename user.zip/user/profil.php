<?php
$pageTitle = 'Profil Saya';
require_once __DIR__ . '/user_header.php';

$uid = (int)$_SESSION['user_id'];
$user = $conn->query("SELECT * FROM pelanggan WHERE id_pelanggan=$uid")->fetch_assoc();

$success = '';
$error   = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nama   = sanitize($_POST['nama'] ?? '');
    $alamat = sanitize($_POST['alamat'] ?? '');
    $no_hp  = sanitize($_POST['no_hp'] ?? '');

    if ($nama) {
        $stmt = $conn->prepare("UPDATE pelanggan SET nama=?, alamat=?, no_hp=? WHERE id_pelanggan=?");
        $stmt->bind_param('sssi', $nama, $alamat, $no_hp, $uid);
        if ($stmt->execute()) {
            $_SESSION['user_nama'] = $nama;
            $success = 'Profil berhasil diperbarui!';
            $user = $conn->query("SELECT * FROM pelanggan WHERE id_pelanggan=$uid")->fetch_assoc();
        } else {
            $error = 'Gagal memperbarui profil.';
        }
    }

    // Ganti password
    if (!empty($_POST['password_lama'])) {
        $lama = $_POST['password_lama'];
        $baru = $_POST['password_baru'] ?? '';
        $konfirmasi = $_POST['password_konfirmasi'] ?? '';

        if (!password_verify($lama, $user['password'])) {
            $error = 'Password lama salah.';
        } elseif (strlen($baru) < 6) {
            $error = 'Password baru minimal 6 karakter.';
        } elseif ($baru !== $konfirmasi) {
            $error = 'Konfirmasi password tidak cocok.';
        } else {
            $hash = password_hash($baru, PASSWORD_BCRYPT);
            $conn->query("UPDATE pelanggan SET password='$hash' WHERE id_pelanggan=$uid");
            $success = 'Password berhasil diubah!';
        }
    }
}
?>

<div class="page-header">
  <h1>Profil Saya ⚙️</h1>
</div>

<?php if($success): ?>
<div class="alert alert-success" data-autodismiss>✅ <?= $success ?></div>
<?php endif; ?>
<?php if($error): ?>
<div class="alert alert-danger" data-autodismiss>⚠️ <?= $error ?></div>
<?php endif; ?>

<div style="display:grid; grid-template-columns:1fr 1fr; gap:24px; align-items:start;">

  <!-- Update Profil -->
  <div class="card" style="padding:28px;">
    <h3 style="margin-bottom:20px;">Data Diri</h3>
    <form method="POST">
      <div class="form-group">
        <label class="form-label">Nama Lengkap</label>
        <input type="text" name="nama" class="form-control" value="<?= htmlspecialchars($user['nama']) ?>" required>
      </div>
      <div class="form-group">
        <label class="form-label">Email</label>
        <input type="email" class="form-control" value="<?= htmlspecialchars($user['email']) ?>" disabled>
        <small style="color:var(--white-dim);">Email tidak dapat diubah</small>
      </div>
      <div class="form-group">
        <label class="form-label">Username</label>
        <input type="text" class="form-control" value="<?= htmlspecialchars($user['username']) ?>" disabled>
      </div>
      <div class="form-group">
        <label class="form-label">No. HP</label>
        <input type="text" name="no_hp" class="form-control" value="<?= htmlspecialchars($user['no_hp'] ?? '') ?>">
      </div>
      <div class="form-group">
        <label class="form-label">Alamat</label>
        <textarea name="alamat" class="form-control" rows="3"><?= htmlspecialchars($user['alamat'] ?? '') ?></textarea>
      </div>
      <button type="submit" class="btn btn-primary btn-block">Simpan Perubahan</button>
    </form>
  </div>

  <!-- Ganti Password -->
  <div class="card" style="padding:28px;">
    <h3 style="margin-bottom:20px;">Ganti Password</h3>
    <form method="POST">
      <div class="form-group">
        <label class="form-label">Password Lama</label>
        <input type="password" name="password_lama" class="form-control" placeholder="Masukkan password lama">
      </div>
      <div class="form-group">
        <label class="form-label">Password Baru</label>
        <input type="password" name="password_baru" class="form-control" placeholder="Min. 6 karakter">
      </div>
      <div class="form-group">
        <label class="form-label">Konfirmasi Password Baru</label>
        <input type="password" name="password_konfirmasi" class="form-control" placeholder="Ulangi password baru">
      </div>
      <button type="submit" class="btn btn-outline btn-block">Ubah Password</button>
    </form>
  </div>

</div>

<?php require_once __DIR__ . '/user_footer.php'; ?>