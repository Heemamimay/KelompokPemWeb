<?php
$pageTitle = 'Kelola Barang';
require_once '../includes/admin_header.php';

// Handle delete
if (isset($_GET['delete'])) {
    $did = (int)$_GET['delete'];
    $conn->query("DELETE FROM barang WHERE id_barang=$did");
    header('Location: barang.php?deleted=1');
    exit();
}

// Search
$search = isset($_GET['q']) ? sanitize($_GET['q']) : '';
$where  = $search ? "WHERE nama_barang LIKE '%$search%' OR merk LIKE '%$search%'" : '';

$perPage = 10;
$page    = max(1, (int)($_GET['page'] ?? 1));
$offset  = ($page - 1) * $perPage;
$total   = $conn->query("SELECT COUNT(*) c FROM barang $where")->fetch_assoc()['c'];
$pages   = ceil($total / $perPage);
$barang  = $conn->query("SELECT * FROM barang $where ORDER BY id_barang DESC LIMIT $perPage OFFSET $offset");
?>

<div class="page-header">
  <div>
    <h1>Kelola Barang</h1>
    <p>Manajemen produk sepatu toko</p>
  </div>
  <a href="tambah_barang.php" class="btn btn-primary">+ Tambah Barang</a>
</div>

<?php if(isset($_GET['deleted'])): ?>
<div class="alert alert-success" data-autodismiss>✓ Barang berhasil dihapus.</div>
<?php endif; ?>
<?php if(isset($_GET['saved'])): ?>
<div class="alert alert-success" data-autodismiss>✓ Data barang berhasil disimpan.</div>
<?php endif; ?>

<!-- Search -->
<form method="GET" style="margin-bottom:24px; display:flex; gap:8px; max-width:400px;">
  <input type="text" name="q" class="form-control" style="margin:0;" placeholder="Cari barang..." value="<?= htmlspecialchars($search) ?>">
  <button class="btn btn-primary" type="submit">Cari</button>
  <?php if($search): ?><a href="barang.php" class="btn btn-outline">Reset</a><?php endif; ?>
</form>

<div class="table-wrapper">
  <div class="table-header">
    <h3>Daftar Barang <span style="color:var(--white-dim);font-weight:400;">(<?= $total ?>)</span></h3>
  </div>
  <table>
    <thead>
      <tr>
        <th>No</th>
        <th>Nama Barang</th>
        <th>Merk</th>
        <th>Harga</th>
        <th>Stok</th>
        <th>Aksi</th>
      </tr>
    </thead>
    <tbody>
      <?php $no = $offset + 1; while($row = $barang->fetch_assoc()): ?>
      <tr>
        <td><?= $no++ ?></td>
        <td>
          <div style="font-weight:600; font-size:.875rem;"><?= htmlspecialchars($row['nama_barang']) ?></div>
        </td>
        <td><span class="card-badge"><?= htmlspecialchars($row['merk']) ?></span></td>
        <td><?= formatRupiah($row['harga']) ?></td>
        <td>
          <span class="badge <?= $row['stok']>5?'badge-selesai':($row['stok']>0?'badge-pending':'badge-dibatalkan') ?>">
            <?= $row['stok'] ?>
          </span>
        </td>
        <td>
          <div style="display:flex; gap:6px;">
            <a href="edit_barang.php?id=<?= $row['id_barang'] ?>" class="btn btn-outline btn-sm">Edit</a>
            <a href="barang.php?delete=<?= $row['id_barang'] ?>" class="btn btn-danger btn-sm"
               data-confirm="Yakin hapus barang ini?">Hapus</a>
          </div>
        </td>
      </tr>
      <?php endwhile; ?>
      <?php if($total === 0): ?>
      <tr><td colspan="6" class="text-center" style="padding:40px; color:var(--white-dim);">Tidak ada data barang</td></tr>
      <?php endif; ?>
    </tbody>
  </table>
</div>

<?php if($pages > 1): ?>
<div class="pagination">
  <?php for($p=1;$p<=$pages;$p++): ?>
    <a href="?page=<?=$p?><?=$search?"&q=".urlencode($search):''?>" class="page-btn <?=$p==$page?'active':''?>"><?=$p?></a>
  <?php endfor; ?>
</div>
<?php endif; ?>

<?php require_once '../includes/admin_footer.php'; ?>
