<?php
$pageTitle = 'Dashboard Admin';
require_once '../includes/admin_header.php';

// Stats
$totalBarang    = $conn->query("SELECT COUNT(*) c FROM barang")->fetch_assoc()['c'];
$totalPelanggan = $conn->query("SELECT COUNT(*) c FROM pelanggan")->fetch_assoc()['c'];
$totalTransaksi = $conn->query("SELECT COUNT(*) c FROM transaksi")->fetch_assoc()['c'];
$totalOmzet     = $conn->query("SELECT IFNULL(SUM(total_harga),0) c FROM transaksi WHERE status='selesai'")->fetch_assoc()['c'];
$transaksiTerbaru = $conn->query("
    SELECT t.*, p.nama FROM transaksi t
    JOIN pelanggan p ON t.id_pelanggan = p.id_pelanggan
    ORDER BY t.tanggal DESC LIMIT 8
");
$stokRendah = $conn->query("SELECT * FROM barang WHERE stok < 5 ORDER BY stok ASC LIMIT 5");
?>

<div class="page-header">
  <div>
    <h1>Dashboard</h1>
    <p>Selamat datang di panel admin SEMBARANG STORE</p>
  </div>
  <span style="font-size:.8rem; color:var(--white-dim);"><?= date('d F Y, H:i') ?></span>
</div>

<!-- Stat Cards -->
<div class="stat-cards">
  <div class="stat-card">
    <div class="stat-card-icon purple">👟</div>
    <div class="stat-card-info">
      <h3><?= $totalBarang ?></h3>
      <p>Total Produk</p>
    </div>
  </div>
  <div class="stat-card">
    <div class="stat-card-icon gold">👤</div>
    <div class="stat-card-info">
      <h3><?= $totalPelanggan ?></h3>
      <p>Total Pelanggan</p>
    </div>
  </div>
  <div class="stat-card">
    <div class="stat-card-icon green">📋</div>
    <div class="stat-card-info">
      <h3><?= $totalTransaksi ?></h3>
      <p>Total Transaksi</p>
    </div>
  </div>
  <div class="stat-card">
    <div class="stat-card-icon red">💰</div>
    <div class="stat-card-info">
      <h3 style="font-size:1.1rem;"><?= formatRupiah($totalOmzet) ?></h3>
      <p>Total Omzet</p>
    </div>
  </div>
</div>

<div style="display:grid; grid-template-columns:1fr 340px; gap:24px; align-items:start;">

  <!-- Transaksi Terbaru -->
  <div class="table-wrapper">
    <div class="table-header">
      <h3>Transaksi Terbaru</h3>
      <a href="transaksi.php" class="btn btn-outline btn-sm">Lihat Semua</a>
    </div>
    <table>
      <thead>
        <tr>
          <th>#ID</th>
          <th>Pelanggan</th>
          <th>Total</th>
          <th>Status</th>
          <th>Tanggal</th>
        </tr>
      </thead>
      <tbody>
        <?php while($t = $transaksiTerbaru->fetch_assoc()): ?>
        <tr>
          <td><strong>#<?= $t['id_transaksi'] ?></strong></td>
          <td><?= htmlspecialchars($t['nama']) ?></td>
          <td><?= formatRupiah($t['total_harga']) ?></td>
          <td><span class="badge badge-<?= $t['status'] ?>"><?= ucfirst($t['status']) ?></span></td>
          <td><?= date('d/m/Y', strtotime($t['tanggal'])) ?></td>
        </tr>
        <?php endwhile; ?>
      </tbody>
    </table>
  </div>

  <!-- Stok Rendah -->
  <div class="table-wrapper">
    <div class="table-header">
      <h3>⚠️ Stok Rendah</h3>
    </div>
    <?php if($stokRendah->num_rows > 0): ?>
    <table>
      <thead><tr><th>Produk</th><th>Stok</th></tr></thead>
      <tbody>
        <?php while($s = $stokRendah->fetch_assoc()): ?>
        <tr>
          <td style="font-size:.82rem;"><?= htmlspecialchars($s['nama_barang']) ?></td>
          <td>
            <span class="badge <?= $s['stok']==0?'badge-dibatalkan':'badge-pending' ?>">
              <?= $s['stok'] ?>
            </span>
          </td>
        </tr>
        <?php endwhile; ?>
      </tbody>
    </table>
    <?php else: ?>
    <div style="padding:24px; text-align:center; color:var(--success); font-size:.875rem;">
      ✓ Semua stok aman
    </div>
    <?php endif; ?>
  </div>

</div>

<?php require_once '../includes/admin_footer.php'; ?>
