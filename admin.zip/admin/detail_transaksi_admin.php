<?php
$pageTitle = 'Detail Transaksi';
require_once '../includes/admin_header.php';

$id = (int)($_GET['id'] ?? 0);
if (!$id) { header('Location: transaksi.php'); exit(); }

$stmt = $conn->prepare("SELECT t.*, p.nama, p.email, p.no_hp, p.alamat FROM transaksi t JOIN pelanggan p ON t.id_pelanggan=p.id_pelanggan WHERE t.id_transaksi=?");
$stmt->bind_param('i',$id);
$stmt->execute();
$trx = $stmt->get_result()->fetch_assoc();
if (!$trx) { header('Location: transaksi.php'); exit(); }

$detail = $conn->query("SELECT dt.*, b.nama_barang, b.merk FROM detail_transaksi dt JOIN barang b ON dt.id_barang=b.id_barang WHERE dt.id_transaksi=$id");
?>

<div class="page-header">
  <div><h1>Detail Transaksi #<?= $id ?></h1><p>Informasi lengkap pesanan</p></div>
  <a href="transaksi.php" class="btn btn-outline">← Kembali</a>
</div>

<div style="display:grid; grid-template-columns:1fr 320px; gap:24px; align-items:start;">

  <!-- Items -->
  <div class="table-wrapper">
    <div class="table-header"><h3>Item Pesanan</h3></div>
    <table>
      <thead>
        <tr><th>Produk</th><th>Merk</th><th>Jumlah</th><th>Subtotal</th></tr>
      </thead>
      <tbody>
        <?php while($d = $detail->fetch_assoc()): ?>
        <tr>
          <td><?= htmlspecialchars($d['nama_barang']) ?></td>
          <td><span class="card-badge"><?= htmlspecialchars($d['merk']) ?></span></td>
          <td><?= $d['jumlah'] ?> pcs</td>
          <td><?= formatRupiah($d['subtotal']) ?></td>
        </tr>
        <?php endwhile; ?>
        <tr>
          <td colspan="3" style="text-align:right; font-weight:700;">Total</td>
          <td style="color:var(--gold); font-weight:700;"><?= formatRupiah($trx['total_harga']) ?></td>
        </tr>
      </tbody>
    </table>
  </div>

  <!-- Info -->
  <div style="display:flex; flex-direction:column; gap:20px;">
    <div class="table-wrapper">
      <div class="table-header"><h3>Info Pelanggan</h3></div>
      <div style="padding:20px;">
        <div style="margin-bottom:12px;">
          <div style="font-size:.75rem; color:var(--white-dim);">Nama</div>
          <div style="font-weight:600;"><?= htmlspecialchars($trx['nama']) ?></div>
        </div>
        <div style="margin-bottom:12px;">
          <div style="font-size:.75rem; color:var(--white-dim);">Email</div>
          <div><?= htmlspecialchars($trx['email']) ?></div>
        </div>
        <div style="margin-bottom:12px;">
          <div style="font-size:.75rem; color:var(--white-dim);">No HP</div>
          <div><?= htmlspecialchars($trx['no_hp'] ?: '-') ?></div>
        </div>
        <div>
          <div style="font-size:.75rem; color:var(--white-dim);">Alamat</div>
          <div style="font-size:.875rem;"><?= htmlspecialchars($trx['alamat'] ?: '-') ?></div>
        </div>
      </div>
    </div>

    <div class="table-wrapper">
      <div class="table-header"><h3>Status Pesanan</h3></div>
      <div style="padding:20px;">
        <div style="margin-bottom:16px;">
          <div style="font-size:.75rem; color:var(--white-dim); margin-bottom:4px;">Tanggal</div>
          <div><?= date('d F Y H:i', strtotime($trx['tanggal'])) ?></div>
        </div>
        <div style="margin-bottom:16px;">
          <div style="font-size:.75rem; color:var(--white-dim); margin-bottom:4px;">Status Saat Ini</div>
          <span class="badge badge-<?= $trx['status'] ?>"><?= ucfirst($trx['status']) ?></span>
        </div>
        <a href="transaksi.php" class="btn btn-outline btn-sm btn-block">Ubah Status</a>
      </div>
    </div>
  </div>
</div>

<?php require_once '../includes/admin_footer.php'; ?>
