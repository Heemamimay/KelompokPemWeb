<?php
$pageTitle = 'Edit Barang';
require_once '../includes/admin_header.php';

$id = (int)($_GET['id'] ?? 0);
if (!$id) { header('Location: barang.php'); exit(); }

$stmt = $conn->prepare("SELECT * FROM barang WHERE id_barang=?");
$stmt->bind_param('i',$id);
$stmt->execute();
$barang = $stmt->get_result()->fetch_assoc();
if (!$barang) { header('Location: barang.php'); exit(); }

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nama      = sanitize($_POST['nama_barang'] ?? '');
    $merk      = sanitize($_POST['merk'] ?? '');
    $harga     = (float)($_POST['harga'] ?? 0);
    $stok      = (int)($_POST['stok'] ?? 0);
    $deskripsi = sanitize($_POST['deskripsi'] ?? '');

    if (!$nama || !$merk || $harga <= 0) {
        $error = 'Mohon isi semua field wajib.';
    } else {
        $stmt = $conn->prepare("UPDATE barang SET nama_barang=?,merk=?,harga=?,stok=?,deskripsi=? WHERE id_barang=?");
        $stmt->bind_param('ssdisi', $nama, $merk, $harga, $stok, $deskripsi, $id);
        if ($stmt->execute()) {
            header('Location: barang.php?saved=1');
            exit();
        } else {
            $error = 'Gagal mengupdate data.';
        }
    }
    $barang['nama_barang'] = $_POST['nama_barang'];
    $barang['merk']        = $_POST['merk'];
    $barang['harga']       = $_POST['harga'];
    $barang['stok']        = $_POST['stok'];
    $barang['deskripsi']   = $_POST['deskripsi'];
}

$merks = ['Compass','Ventela','Aerostreet','Piero','NAH Project','Brand Lainnya'];
?>

<div class="page-header">
  <div>
    <h1>Edit Barang</h1>
    <p>Perbarui data produk</p>
  </div>
  <a href="barang.php" class="btn btn-outline">← Kembali</a>
</div>

<?php if($error): ?>
<div class="alert alert-danger" data-autodismiss>⚠️ <?= $error ?></div>
<?php endif; ?>

<div style="max-width:640px;">
  <div class="table-wrapper">
    <div class="table-header"><h3>Form Edit Barang #<?= $id ?></h3></div>
    <div style="padding:28px;">
      <form method="POST">
        <div class="form-group">
          <label class="form-label">Nama Barang *</label>
          <input type="text" name="nama_barang" class="form-control"
                 value="<?= htmlspecialchars($barang['nama_barang']) ?>" required>
        </div>

        <div class="form-row">
          <div class="form-group">
            <label class="form-label">Merk *</label>
            <select name="merk" class="form-control" required>
              <?php foreach($merks as $m): ?>
              <option value="<?= $m ?>" <?= $barang['merk']===$m?'selected':'' ?>><?= $m ?></option>
              <?php endforeach; ?>
            </select>
          </div>
          <div class="form-group">
            <label class="form-label">Harga (Rp) *</label>
            <input type="number" name="harga" class="form-control"
                   value="<?= $barang['harga'] ?>" min="0" required>
          </div>
        </div>

        <div class="form-group">
          <label class="form-label">Stok</label>
          <input type="number" name="stok" class="form-control"
                 value="<?= $barang['stok'] ?>" min="0">
        </div>

        <div class="form-group">
          <label class="form-label">Deskripsi</label>
          <textarea name="deskripsi" class="form-control" rows="4"><?= htmlspecialchars($barang['deskripsi']) ?></textarea>
        </div>

        <div style="display:flex; gap:12px;">
          <button type="submit" class="btn btn-primary">Simpan Perubahan</button>
          <a href="barang.php" class="btn btn-outline">Batal</a>
        </div>
      </form>
    </div>
  </div>
</div>

<?php require_once '../includes/admin_footer.php'; ?>
