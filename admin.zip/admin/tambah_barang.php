<?php
$pageTitle = 'Tambah Barang';
require_once '../includes/admin_header.php';

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nama    = sanitize($_POST['nama_barang'] ?? '');
    $merk    = sanitize($_POST['merk'] ?? '');
    $harga   = (float)($_POST['harga'] ?? 0);
    $stok    = (int)($_POST['stok'] ?? 0);
    $deskripsi = sanitize($_POST['deskripsi'] ?? '');

    if (!$nama || !$merk || $harga <= 0) {
        $error = 'Mohon isi semua field wajib dengan benar.';
    } else {
        $stmt = $conn->prepare("INSERT INTO barang (nama_barang,merk,harga,stok,deskripsi,gambar) VALUES (?,?,?,?,?,'default.jpg')");
        $stmt->bind_param('ssdis', $nama, $merk, $harga, $stok, $deskripsi);
        if ($stmt->execute()) {
            header('Location: barang.php?saved=1');
            exit();
        } else {
            $error = 'Gagal menyimpan data.';
        }
    }
}

$merks = ['Compass','Ventela','Aerostreet','Piero','NAH Project','Brand Lainnya'];
?>

<div class="page-header">
  <div>
    <h1>Tambah Barang</h1>
    <p>Tambah produk baru ke toko</p>
  </div>
  <a href="barang.php" class="btn btn-outline">← Kembali</a>
</div>

<?php if($error): ?>
<div class="alert alert-danger" data-autodismiss>⚠️ <?= $error ?></div>
<?php endif; ?>

<div style="max-width:640px;">
  <div class="table-wrapper">
    <div class="table-header"><h3>Form Tambah Barang</h3></div>
    <div style="padding:28px;">
      <form method="POST">
        <div class="form-group">
          <label class="form-label">Nama Barang *</label>
          <input type="text" name="nama_barang" class="form-control" placeholder="Contoh: Compass Gazelle Low Black"
                 value="<?= htmlspecialchars($_POST['nama_barang'] ?? '') ?>" required>
        </div>

        <div class="form-row">
          <div class="form-group">
            <label class="form-label">Merk *</label>
            <select name="merk" class="form-control" required>
              <option value="">-- Pilih Merk --</option>
              <?php foreach($merks as $m): ?>
              <option value="<?= $m ?>" <?= ($_POST['merk']??'')===$m?'selected':'' ?>><?= $m ?></option>
              <?php endforeach; ?>
            </select>
          </div>
          <div class="form-group">
            <label class="form-label">Harga (Rp) *</label>
            <input type="number" name="harga" class="form-control" placeholder="0"
                   value="<?= htmlspecialchars($_POST['harga'] ?? '') ?>" min="0" required>
          </div>
        </div>

        <div class="form-group">
          <label class="form-label">Stok</label>
          <input type="number" name="stok" class="form-control" placeholder="0"
                 value="<?= htmlspecialchars($_POST['stok'] ?? '0') ?>" min="0">
        </div>

        <div class="form-group">
          <label class="form-label">Deskripsi Produk</label>
          <textarea name="deskripsi" class="form-control" rows="4" placeholder="Deskripsi produk..."><?= htmlspecialchars($_POST['deskripsi'] ?? '') ?></textarea>
        </div>

        <div style="display:flex; gap:12px;">
          <button type="submit" class="btn btn-primary">Simpan Barang</button>
          <a href="barang.php" class="btn btn-outline">Batal</a>
        </div>
      </form>
    </div>
  </div>
</div>

<?php require_once '../includes/admin_footer.php'; ?>
