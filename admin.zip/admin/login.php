<?php
if (session_status() === PHP_SESSION_NONE) session_start();
require_once '../includes/config.php';

if (isAdminLoggedIn()) {
    header('Location: dashboard.php');
    exit();
}

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = sanitize($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';

    if ($username && $password) {
        $stmt = $conn->prepare("SELECT * FROM admin WHERE username = ?");
        $stmt->bind_param('s', $username);
        $stmt->execute();
        $admin = $stmt->get_result()->fetch_assoc();

        if ($admin && password_verify($password, $admin['password'])) {
            $_SESSION['admin_id']       = $admin['id_admin'];
            $_SESSION['admin_username'] = $admin['username'];
            header('Location: dashboard.php');
            exit();
        } else {
            $error = 'Username atau password admin salah.';
        }
    } else {
        $error = 'Mohon isi semua field.';
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Admin Login - SEMBARANG STORE</title>
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700;800&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="<?= BASE_URL ?>/assets/css/style.css">
</head>
<body>

<div class="auth-wrapper">
  <div class="auth-box animate-fade-in">
    <div class="auth-logo">
      <h2>⚡ <span class="gradient-text">ADMIN PANEL</span></h2>
      <p>SEMBARANG STORE Management</p>
    </div>

    <?php if($error): ?>
    <div class="alert alert-danger" data-autodismiss>⚠️ <?= $error ?></div>
    <?php endif; ?>

    <?php if(isset($_GET['logout'])): ?>
    <div class="alert alert-success" data-autodismiss>✓ Berhasil logout.</div>
    <?php endif; ?>

    <form method="POST">
      <div class="form-group">
        <label class="form-label">Username Admin</label>
        <input type="text" name="username" class="form-control" placeholder="Username admin" required>
      </div>
      <div class="form-group">
        <label class="form-label">Password</label>
        <input type="password" name="password" class="form-control" placeholder="Password admin" required>
      </div>
      <button type="submit" class="btn btn-primary btn-block">Masuk ke Panel</button>
    </form>

    <p class="text-center mt-3" style="font-size:.8rem; color:var(--white-dim);">
      <a href="<?= BASE_URL ?>/index.php" style="color:rgba(255,255,255,.35);">← Kembali ke Toko</a>
    </p>

    <div class="alert alert-info mt-3" style="font-size:.78rem;">
      💡 Demo admin: <strong>admin</strong> / <strong>password</strong>
    </div>
  </div>
</div>

<script src="<?= BASE_URL ?>/assets/js/main.js"></script>
</body>
</html>
