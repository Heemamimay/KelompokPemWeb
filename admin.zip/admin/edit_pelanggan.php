<?php
$pageTitle = 'Edit Pelanggan';
require_once '../includes/admin_header.php';

$id = (int)($_GET['id'] ?? 0);
if (!$id) { header('Location: pelanggan.php'); exit(); }

$stmt = $conn->prepare("SELECT * FROM pelanggan WHERE id_pelanggan=?");
$stmt->bind_param('i',$id);
$stmt->execute();
$p = $stmt->get_result()->fetch_assoc();
if (!$p) { header('Location: pelanggan.php'); exit(); }

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nama  = sanitize($_POST['nama'] ?? '');
    $email = sanitize($_POST['email'] ?? '');
    $alamat= sanitize($_POST['alamat'] ?? '');
    $no_hp = sanitize($_POST['no_hp'] ?? '');

    if (!$nama || !$email) {
        $error = 'Nama dan email wajib diisi.';
    } else {
        $stmt = $conn->prepare("UPDATE pelanggan SET nama=?,email=?,alamat=?,no_hp=? WHERE id_pelanggan=?");
        $stmt->bind_param('ssssi',$nama,$email,$alamat,$no_hp,$id);
        if($stmt->execute()) {
            header('Location: pelanggan.php?saved=1');
            exit();
        } else { $error = 'Gagal menyimpan.'; }
    }
    $p['nama']  = $_POST['nama'];
    $p['email'] = $_POST['email'];
    $p['alamat']= $_POST['alamat'];
    $p['no_hp'] = $_POST['no_hp'];
}
?>

<div class="page-header">
  <div><h1>Edit Pelanggan</h1><p>Perbarui data akun pelanggan</p></div>
  <a href="pelanggan.php" class="btn btn-outline">← Kembali</a>
</div>

<?php if($error): ?>
<div class="alert alert-danger" data-autodismiss>⚠️ <?= $error ?></div>
<?php endif; ?>

<div style="max-width:580px;">
  <div class="table-wrapper">
    <div class="table-header"><h3>Form Edit Pelanggan</h3></div>
    <div style="padding:28px;">
      <form method="POST">
        <div class="form-row">
          <div class="form-group">
            <label class="form-label">Nama *</label>
            <input type="text" name="nama" class="form-control" value="<?= htmlspecialchars($p['nama']) ?>" required>
          </div>
          <div class="form-group">
            <label class="form-label">No HP</label>
            <input type="text" name="no_hp" class="form-control" value="<?= htmlspecialchars($p['no_hp']) ?>">
          </div>
        </div>
        <div class="form-group">
          <label class="form-label">Email *</label>
          <input type="email" name="email" class="form-control" value="<?= htmlspecialchars($p['email']) ?>" required>
        </div>
        <div class="form-group">
          <label class="form-label">Username <span style="color:var(--white-dim);font-size:.8rem;">(tidak bisa diubah)</span></label>
          <input type="text" class="form-control" value="<?= htmlspecialchars($p['username']) ?>" disabled>
        </div>
        <div class="form-group">
          <label class="form-label">Alamat</label>
          <textarea name="alamat" class="form-control" rows="3"><?= htmlspecialchars($p['alamat']) ?></textarea>
        </div>
        <div style="display:flex;gap:12px;">
          <button type="submit" class="btn btn-primary">Simpan</button>
          <a href="pelanggan.php" class="btn btn-outline">Batal</a>
        </div>
      </form>
    </div>
  </div>
</div>

<?php require_once '../includes/admin_footer.php'; ?>
