<?php
$pageTitle = 'Kelola Pelanggan';
require_once '../includes/admin_header.php';

// Delete
if (isset($_GET['delete'])) {
    $did = (int)$_GET['delete'];
    $conn->query("DELETE FROM pelanggan WHERE id_pelanggan=$did");
    header('Location: pelanggan.php?deleted=1');
    exit();
}

$search = isset($_GET['q']) ? sanitize($_GET['q']) : '';
$where  = $search ? "WHERE nama LIKE '%$search%' OR email LIKE '%$search%' OR username LIKE '%$search%'" : '';

$perPage = 10;
$page    = max(1, (int)($_GET['page'] ?? 1));
$offset  = ($page - 1) * $perPage;
$total   = $conn->query("SELECT COUNT(*) c FROM pelanggan $where")->fetch_assoc()['c'];
$pages   = ceil($total / $perPage);
$data    = $conn->query("SELECT p.*, (SELECT COUNT(*) FROM transaksi t WHERE t.id_pelanggan=p.id_pelanggan) as total_transaksi FROM pelanggan p $where ORDER BY id_pelanggan DESC LIMIT $perPage OFFSET $offset");
?>

<div class="page-header">
  <div>
    <h1>Kelola Pelanggan</h1>
    <p>Data akun pelanggan toko</p>
  </div>
</div>

<?php if(isset($_GET['deleted'])): ?>
<div class="alert alert-success" data-autodismiss>✓ Pelanggan berhasil dihapus.</div>
<?php endif; ?>
<?php if(isset($_GET['saved'])): ?>
<div class="alert alert-success" data-autodismiss>✓ Data pelanggan berhasil diperbarui.</div>
<?php endif; ?>

<form method="GET" style="margin-bottom:24px; display:flex; gap:8px; max-width:400px;">
  <input type="text" name="q" class="form-control" style="margin:0;" placeholder="Cari nama/email/username..." value="<?= htmlspecialchars($search) ?>">
  <button class="btn btn-primary" type="submit">Cari</button>
  <?php if($search): ?><a href="pelanggan.php" class="btn btn-outline">Reset</a><?php endif; ?>
</form>

<div class="table-wrapper">
  <div class="table-header">
    <h3>Data Pelanggan <span style="color:var(--white-dim);font-weight:400;">(<?= $total ?>)</span></h3>
  </div>
  <table>
    <thead>
      <tr>
        <th>No</th>
        <th>Nama</th>
        <th>Username</th>
        <th>Email</th>
        <th>No HP</th>
        <th>Transaksi</th>
        <th>Aksi</th>
      </tr>
    </thead>
    <tbody>
      <?php $no = $offset + 1; while($row = $data->fetch_assoc()): ?>
      <tr>
        <td><?= $no++ ?></td>
        <td><strong><?= htmlspecialchars($row['nama']) ?></strong></td>
        <td style="color:var(--purple-glow);">@<?= htmlspecialchars($row['username']) ?></td>
        <td style="font-size:.83rem;"><?= htmlspecialchars($row['email']) ?></td>
        <td style="font-size:.83rem;"><?= htmlspecialchars($row['no_hp'] ?: '-') ?></td>
        <td><span class="badge badge-diproses"><?= $row['total_transaksi'] ?></span></td>
        <td>
          <div style="display:flex; gap:6px;">
            <a href="edit_pelanggan.php?id=<?= $row['id_pelanggan'] ?>" class="btn btn-outline btn-sm">Edit</a>
            <a href="pelanggan.php?delete=<?= $row['id_pelanggan'] ?>" class="btn btn-danger btn-sm"
               data-confirm="Yakin hapus pelanggan ini? Semua transaksinya juga akan terhapus!">Hapus</a>
          </div>
        </td>
      </tr>
      <?php endwhile; ?>
      <?php if($total===0): ?>
      <tr><td colspan="7" class="text-center" style="padding:40px;color:var(--white-dim);">Belum ada data pelanggan</td></tr>
      <?php endif; ?>
    </tbody>
  </table>
</div>

<?php if($pages>1): ?>
<div class="pagination">
  <?php for($p=1;$p<=$pages;$p++): ?>
    <a href="?page=<?=$p?><?=$search?"&q=".urlencode($search):''?>" class="page-btn <?=$p==$page?'active':''?>"><?=$p?></a>
  <?php endfor; ?>
</div>
<?php endif; ?>

<?php require_once '../includes/admin_footer.php'; ?>
