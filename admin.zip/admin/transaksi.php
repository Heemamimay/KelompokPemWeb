<?php
$pageTitle = 'Kelola Transaksi';
require_once '../includes/admin_header.php';

// Update status
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_status'])) {
    $tid    = (int)$_POST['id_transaksi'];
    $status = sanitize($_POST['status']);
    $validStatus = ['pending','diproses','dikirim','selesai','dibatalkan'];
    if (in_array($status, $validStatus)) {
        $conn->query("UPDATE transaksi SET status='$status' WHERE id_transaksi=$tid");
    }
    header('Location: transaksi.php?updated=1');
    exit();
}

$filter = isset($_GET['status']) ? sanitize($_GET['status']) : '';
$where  = $filter ? "WHERE t.status='$filter'" : '';

$perPage = 10;
$page    = max(1,(int)($_GET['page']??1));
$offset  = ($page-1)*$perPage;
$total   = $conn->query("SELECT COUNT(*) c FROM transaksi t $where")->fetch_assoc()['c'];
$pages   = ceil($total/$perPage);
$data    = $conn->query("
    SELECT t.*, p.nama, p.email FROM transaksi t
    JOIN pelanggan p ON t.id_pelanggan=p.id_pelanggan
    $where ORDER BY t.tanggal DESC LIMIT $perPage OFFSET $offset
");

$statuses = ['','pending','diproses','dikirim','selesai','dibatalkan'];
$statusLabel = [''=> 'Semua','pending'=>'Pending','diproses'=>'Diproses','dikirim'=>'Dikirim','selesai'=>'Selesai','dibatalkan'=>'Dibatalkan'];
?>

<div class="page-header">
  <div><h1>Kelola Transaksi</h1><p>Manajemen dan status pesanan</p></div>
</div>

<?php if(isset($_GET['updated'])): ?>
<div class="alert alert-success" data-autodismiss>✓ Status transaksi berhasil diperbarui.</div>
<?php endif; ?>

<!-- Filter Status -->
<div style="display:flex; gap:8px; flex-wrap:wrap; margin-bottom:24px;">
  <?php foreach($statuses as $s): ?>
  <a href="transaksi.php<?= $s?"?status=$s":'' ?>"
     class="btn btn-sm <?= $filter===$s?'btn-primary':'btn-outline' ?>">
    <?= $statusLabel[$s] ?>
  </a>
  <?php endforeach; ?>
</div>

<div class="table-wrapper">
  <div class="table-header">
    <h3>Semua Transaksi <span style="color:var(--white-dim);font-weight:400;">(<?= $total ?>)</span></h3>
  </div>
  <table>
    <thead>
      <tr>
        <th>#ID</th>
        <th>Pelanggan</th>
        <th>Tanggal</th>
        <th>Total</th>
        <th>Status</th>
        <th>Ubah Status</th>
        <th>Detail</th>
      </tr>
    </thead>
    <tbody>
      <?php while($row = $data->fetch_assoc()): ?>
      <tr>
        <td><strong>#<?= $row['id_transaksi'] ?></strong></td>
        <td>
          <div style="font-weight:600;font-size:.875rem;"><?= htmlspecialchars($row['nama']) ?></div>
          <div style="font-size:.75rem;color:var(--white-dim);"><?= htmlspecialchars($row['email']) ?></div>
        </td>
        <td style="font-size:.83rem;"><?= date('d M Y H:i', strtotime($row['tanggal'])) ?></td>
        <td><?= formatRupiah($row['total_harga']) ?></td>
        <td><span class="badge badge-<?= $row['status'] ?>"><?= ucfirst($row['status']) ?></span></td>
        <td>
          <form method="POST" style="display:flex;gap:6px;align-items:center;">
            <input type="hidden" name="id_transaksi" value="<?= $row['id_transaksi'] ?>">
            <select name="status" class="form-control" style="margin:0;padding:6px 10px;font-size:.8rem;width:auto;">
              <?php foreach(['pending','diproses','dikirim','selesai','dibatalkan'] as $s): ?>
              <option value="<?= $s ?>" <?= $row['status']===$s?'selected':'' ?>><?= ucfirst($s) ?></option>
              <?php endforeach; ?>
            </select>
            <button type="submit" name="update_status" class="btn btn-primary btn-sm">✓</button>
          </form>
        </td>
        <td>
          <a href="detail_transaksi_admin.php?id=<?= $row['id_transaksi'] ?>" class="btn btn-outline btn-sm">Detail</a>
        </td>
      </tr>
      <?php endwhile; ?>
      <?php if($total===0): ?>
      <tr><td colspan="7" class="text-center" style="padding:40px;color:var(--white-dim);">Belum ada transaksi</td></tr>
      <?php endif; ?>
    </tbody>
  </table>
</div>

<?php if($pages>1): ?>
<div class="pagination">
  <?php for($p=1;$p<=$pages;$p++): ?>
    <a href="?page=<?=$p?><?=$filter?"&status=$filter":''?>" class="page-btn <?=$p==$page?'active':''?>"><?=$p?></a>
  <?php endfor; ?>
</div>
<?php endif; ?>

<?php require_once '../includes/admin_footer.php'; ?>
