<?php
// =============================================
// SEMBARANG STORE - Konfigurasi Database
// =============================================

define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'sembarang_store');

$conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);

if ($conn->connect_error) {
    die('<div style="font-family:Poppins,sans-serif;padding:40px;text-align:center;background:#0a0015;color:#ff4d6d;min-height:100vh;">
        <h2>⚠️ Koneksi Database Gagal</h2>
        <p>Pastikan MySQL sudah berjalan di Laragon dan database <strong>sembarang_store</strong> sudah di-import.</p>
        <p>Error: ' . $conn->connect_error . '</p>
    </div>');
}

$conn->set_charset('utf8mb4');

// Base URL helper
define('BASE_URL', 'http://localhost/sembarang_store');

// Session helper
function isAdminLoggedIn() {
    return isset($_SESSION['admin_id']) && !empty($_SESSION['admin_id']);
}

function isUserLoggedIn() {
    return isset($_SESSION['user_id']) && !empty($_SESSION['user_id']);
}

function redirectIfNotAdmin() {
    if (!isAdminLoggedIn()) {
        header('Location: ' . BASE_URL . '/admin/login.php');
        exit();
    }
}

function redirectIfNotUser() {
    if (!isUserLoggedIn()) {
        header('Location: ' . BASE_URL . '/login.php');
        exit();
    }
}

function formatRupiah($angka) {
    return 'Rp ' . number_format($angka, 0, ',', '.');
}

function sanitize($data) {
    global $conn;
    return $conn->real_escape_string(htmlspecialchars(strip_tags(trim($data))));
}
?>
