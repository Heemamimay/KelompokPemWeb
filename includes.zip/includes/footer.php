<footer class="footer">
  <div class="footer-grid">
    <div class="footer-brand">
      <h3>SEMBARANG STORE</h3>
      <p>Toko sepatu lokal Indonesia terpercaya. Temukan koleksi terbaik dari brand-brand lokal kebanggaan seperti Compass, Ventela, Aerostreet, Piero, NAH Project, dan banyak lagi.</p>
    </div>
    <div class="footer-col">
      <h4>Navigasi</h4>
      <ul>
        <li><a href="<?= BASE_URL ?>/index.php">Beranda</a></li>
        <li><a href="<?= BASE_URL ?>/produk.php">Produk</a></li>
        <li><a href="<?= BASE_URL ?>/tentang.php">Tentang Kami</a></li>
        <li><a href="<?= BASE_URL ?>/login.php">Login</a></li>
        <li><a href="<?= BASE_URL ?>/register.php">Daftar</a></li>
      </ul>
    </div>
    <div class="footer-col">
      <h4>Brand Pilihan</h4>
      <ul>
        <li><a href="#">Compass</a></li>
        <li><a href="#">Ventela</a></li>
        <li><a href="#">Aerostreet</a></li>
        <li><a href="#">Piero</a></li>
        <li><a href="#">NAH Project</a></li>
      </ul>
    </div>
  </div>
  <div class="footer-bottom">
    <p>&copy; <?= date('Y') ?> SEMBARANG STORE. Dibuat dengan ❤️ untuk brand lokal Indonesia.</p>
  </div>
</footer>

<script src="<?= BASE_URL ?>/assets/js/main.js"></script>
</body>
</html>
