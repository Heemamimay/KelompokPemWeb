<?php
if (session_status() === PHP_SESSION_NONE) session_start();
require_once __DIR__ . '/config.php';
redirectIfNotAdmin();
$adminUser = $_SESSION['admin_username'] ?? 'Admin';
$activePage = basename($_SERVER['PHP_SELF'], '.php');
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title><?= isset($pageTitle) ? $pageTitle . ' - Admin Panel' : 'Admin Panel' ?></title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="<?= BASE_URL ?>/assets/css/style.css">
</head>
<body>
<div class="dashboard-layout">

  <!-- Sidebar -->
  <aside class="sidebar" id="sidebar">
    <div class="sidebar-logo">
      <h3>⚡ SEMBARANG</h3>
      <p>Panel Admin · <?= htmlspecialchars($adminUser) ?></p>
    </div>

    <nav class="sidebar-nav">
      <div class="sidebar-section-label">Utama</div>
      <a href="<?= BASE_URL ?>/admin/dashboard.php"
         class="sidebar-link <?= $activePage==='dashboard'?'active':'' ?>">
        <span class="icon">📊</span> Dashboard
      </a>

      <div class="sidebar-section-label">Kelola Data</div>
      <a href="<?= BASE_URL ?>/admin/barang.php"
         class="sidebar-link <?= in_array($activePage,['barang','tambah_barang','edit_barang'])?'active':'' ?>">
        <span class="icon">👟</span> Kelola Barang
      </a>
      <a href="<?= BASE_URL ?>/admin/pelanggan.php"
         class="sidebar-link <?= in_array($activePage,['pelanggan','edit_pelanggan'])?'active':'' ?>">
        <span class="icon">👤</span> Kelola Pelanggan
      </a>
      <a href="<?= BASE_URL ?>/admin/transaksi.php"
         class="sidebar-link <?= in_array($activePage,['transaksi','detail_transaksi_admin'])?'active':'' ?>">
        <span class="icon">📋</span> Kelola Transaksi
      </a>
    </nav>

    <div class="sidebar-footer">
      <a href="<?= BASE_URL ?>/admin/logout.php" class="sidebar-link"
         data-confirm="Yakin ingin logout?">
        <span class="icon">🚪</span> Logout
      </a>
    </div>
  </aside>

  <!-- Main -->
  <main class="main-content">
    <div style="display:flex;align-items:center;gap:12px;margin-bottom:24px;padding-bottom:16px;border-bottom:1px solid var(--card-border);">
      <button id="sidebarToggle" style="background:none;border:none;color:var(--white);font-size:1.4rem;cursor:pointer;display:none;">☰</button>
      <span style="font-size:.85rem;color:var(--white-dim);">Panel Admin</span>
    </div>
    <style>@media(max-width:1024px){#sidebarToggle{display:flex!important;}}</style>
