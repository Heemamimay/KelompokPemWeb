  </main><!-- end .main-content -->
</div><!-- end .dashboard-layout -->

<script src="<?= BASE_URL ?>/assets/js/main.js"></script>
</body>
</html>
