<?php
if (session_status() === PHP_SESSION_NONE) session_start();
require_once __DIR__ . '/config.php';
$currentPage = basename($_SERVER['PHP_SELF'], '.php');
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title><?= isset($pageTitle) ? $pageTitle . ' - SEMBARANG STORE' : 'SEMBARANG STORE' ?></title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700;800;900&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="<?= BASE_URL ?>/assets/css/style.css">
</head>
<body>

<nav class="navbar">
  <a href="<?= BASE_URL ?>/index.php" class="navbar-brand">SEMBARANG<span>STORE</span></a>

  <button class="hamburger" id="hamburger" aria-label="Menu">
    <span></span><span></span><span></span>
  </button>

  <ul class="navbar-nav" id="navMenu">
    <li><a href="<?= BASE_URL ?>/index.php" class="nav-link <?= $currentPage==='index'?'active':'' ?>">Beranda</a></li>
    <li><a href="<?= BASE_URL ?>/produk.php" class="nav-link <?= $currentPage==='produk'?'active':'' ?>">Produk</a></li>
    <li><a href="<?= BASE_URL ?>/tentang.php" class="nav-link <?= $currentPage==='tentang'?'active':'' ?>">Tentang</a></li>

    <?php if (isUserLoggedIn()): ?>
      <li><a href="<?= BASE_URL ?>/user/keranjang.php" class="nav-link">🛒 Keranjang</a></li>
      <li><a href="<?= BASE_URL ?>/user/dashboard.php" class="nav-btn nav-link">Dashboard</a></li>
    <?php else: ?>
      <li><a href="<?= BASE_URL ?>/login.php" class="nav-link <?= $currentPage==='login'?'active':'' ?>">Login</a></li>
      <li><a href="<?= BASE_URL ?>/register.php" class="nav-btn nav-btn-gold nav-link">Daftar</a></li>
    <?php endif; ?>
  </ul>
</nav>
